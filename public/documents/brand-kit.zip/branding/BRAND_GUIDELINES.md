# Temvorel brand guidelines

**Temvorel** is the product name. Use title case in prose and the wordmark; use `temvorel` for identifiers. Pronounced **TEM-vor-el**, the coined name combines tempo, vow and release: commitments released with a clear rhythm.

**Value, on your terms.**

The prepared domain is **temvorel.xyz** and the prepared X handle is **@temvorel**. Availability evidence lives in `docs/rebrand-2026/`; identifiers are not reserved or owned by preparing these assets. Use a domain as a live call to action only after ownership, hosting and HTTPS are verified.

## Product and voice

Temvorel is a token release workspace for vesting, whole-date locks, finite streams and vested distributions. Describe observable behavior with direct language: set terms, review, fund, inspect and claim. Keep the **Robinhood Chain Testnet** stage visible. Do not imply network affiliation, independent audit, investment return, customer adoption or a future token entitlement.

The deployed test token retains the immutable name **Vestlyr Test USD** (`tUSD`). That historical contract metadata is not the current product brand. Contract addresses and existing schedule rights remain unchanged.

## Visual system

| Color | Hex | Role |
| --- | --- | --- |
| Ink | `#18202c` | Text, structure and strong anchors |
| Cobalt | `#355dff` | Primary actions, release tracks and selected states |
| Accessible blue | `#2e51e6` | Small interface text and button backgrounds |
| Muted | `#5e6a7b` | Supporting text, including pale-blue panels |
| Paper | `#ffffff` | Main surfaces and reverse marks |
| Mist | `#f3f4f6` | Workspace background |
| Pale blue | `#e9eeff` | Supporting panels |
| Orange | `#fa9a5b` | Sparse timeline/control accents |

Use a measured grid, clear spacing, thin rules, time ticks and decisive large typography. A visible control point represents a timing decision. Avoid decorative sculpture, gradients, soft card piles and unexplained financial counters. Ink on paper and white on cobalt are primary text pairings; orange is an accent, not a small text color on white.

The mark consists of three 3-unit horizontal tracks from x=6 to x=42 at y=12, 24 and 36 in a 48×48 view box. Three 10×10 control points start at (12,7), (26,19) and (17,31). Keep its proportions and allow at least 8 view-box units of surrounding clear space. Use `logo.svg` on light surfaces, `logo-light.svg` on cobalt or ink. `logo-ivory.svg` is a compatibility filename for the same white mark. The wordmark uses outlined Manrope glyphs for portable rendering.

## Asset inventory and reproduction

- `logo*.svg`, `wordmark*.svg`, `favicon.svg`: scalable marks.
- `avatar.png` and `twitter/avatar.jpg`: 400×400 profile artwork, safe for circular cropping.
- `twitter/banner.jpg`: 1500×500, essential copy kept clear of the lower-left avatar overlap.
- `website/public/brand/og-image.jpg`: 1200×630 social preview.
- `twitter/01-introducing-temvorel.jpg`, `02-release-map.jpg`, `03-shared-timing.jpg`: three 1600×900 launch cards.
- `twitter/posts.md` and `bio.txt`: English drafts with alt text.

Run `python branding/sources/build_brand.py` to regenerate assets. Run `python branding/sources/build_business_plan.py`, then the included `render_business_plan.ps1`, to regenerate the print edition. Run `python branding/sources/package_materials.py` after validation to refresh public downloads and the brand kit. The dependencies are Pillow, fonttools, Markdown and a local Chromium browser for PDF printing. The supplied Manrope font is licensed under SIL OFL.

These are prepared materials. Asset creation does not publish a post, register an account, purchase a domain or establish legal exclusivity.
