# Asset provenance

Prepared for **Temvorel**, 17 September 2026.

| Asset | Origin |
| --- | --- |
| Three-track mark and favicon | Project-specific vector geometry in `sources/build_brand.py` |
| Wordmark | Original composition of outlined Manrope glyphs |
| Social cards, banner and OG | Locally drawn timeline grids and control points, composed in `sources/build_brand.py` |
| Business plan print layout | Local HTML/CSS layout in `sources/build_business_plan.py`; content from `docs/business-plan.md` |
| Manrope | Google Fonts distribution, SIL Open Font License, included as `sources/Manrope-OFL.txt` |

Font source: https://github.com/google/fonts/tree/main/ofl/manrope

No third-party project artwork, screenshot, logo, mascot or stock image is used. The assets are deterministic code-native geometry and raster exports, not AI-generated images. The prior sculpture and its production script were removed from the active material set.

This records asset origin and licensing. It does not assert trademark clearance, global name uniqueness or ownership of the prepared domain and handle.
