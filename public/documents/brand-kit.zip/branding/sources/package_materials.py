"""Copy an explicit allowlist of current documents and build the Temvorel kit."""
from pathlib import Path
from shutil import copy2
from zipfile import ZipFile, ZIP_DEFLATED
import json

ROOT=Path(__file__).resolve().parents[2]
PUBLIC=ROOT/'website/public/documents'
PUBLIC.mkdir(parents=True,exist_ok=True)
docs=['business-plan.md','business-plan.html','business-plan.pdf','contracts.md','research.md','launch-checklist.md','name-availability.md','completion-audit-name.md','completion-audit.md','validation.md','reference-parity-audit.md','materials-validation.json']
for filename in docs:
    source=ROOT/'docs'/filename
    if source.exists(): copy2(source,PUBLIC/filename)
for filename in ['TokenSchedulesV2.sol','TokenSchedules.sol','MockUSD.sol']:
    source=ROOT/'contracts/src'/filename
    if source.exists(): copy2(source,PUBLIC/filename)

# Publish selected current identity evidence, not the bulky internal search archive.
proof=PUBLIC/'rebrand-2026'; proof.mkdir(exist_ok=True)
evidence=['temvorel-xyz.json','temvorel-xyz-whois.json','temvorel-fun.json','temvorel-fun-whois.json','temvorel-top.json','temvorel-top-whois.json','temvorel-x-final.json','temvorel-x-official.json','temvorel-github.json','temvorel-github-users.json','temvorel-npm.json','temvorel-coingecko.json','temvorel-bing-exact-rendered.json','temvorel-bing-unquoted-rendered.json']
for filename in evidence: copy2(ROOT/'docs/rebrand-2026'/filename,proof/filename)
selected=json.loads((ROOT/'docs/rebrand-2026/selected-brand.json').read_text(encoding='utf-8'))
selected.pop('rejectedCandidate',None)
(proof/'selected-brand.json').write_text(json.dumps(selected,indent=2),encoding='utf-8')
proof_text='''# Temvorel — public availability evidence

Prepared identity: **Temvorel / temvorel.xyz / @temvorel**. No purchase, registration or reservation was performed.

On 17 September 2026, registry WHOIS checks at 14:47:11–13 UTC found the three proposed domains unregistered/available. X's official username endpoint at 14:45:45 UTC returned `valid:true`, `reason:available`, `msg:Available!`. Availability can change immediately; registrar eligibility and price must be checked at purchase.

| Identifier | Evidence |
| --- | --- |
| temvorel.xyz | [RDAP](temvorel-xyz.json), [WHOIS](temvorel-xyz-whois.json) |
| temvorel.fun | [RDAP](temvorel-fun.json), [WHOIS](temvorel-fun-whois.json) |
| temvorel.top | [RDAP](temvorel-top.json), [WHOIS](temvorel-top-whois.json) |
| @temvorel | [Initial official response](temvorel-x-official.json), [final official response](temvorel-x-final.json) |

The available local prior-brand records contained no match. Rendered Bing searches with and without quotes showed no same-spelling result title or snippet. GitHub repositories/users, npm and CoinGecko returned no match. Coverage is limited to the inspected results; other engines required human verification. These checks do not prove that the name has never existed anywhere online or establish trademark clearance. [Quoted search](temvorel-bing-exact-rendered.json), [unquoted search](temvorel-bing-unquoted-rendered.json), [GitHub repositories](temvorel-github.json), [GitHub users](temvorel-github-users.json), [npm](temvorel-npm.json), [CoinGecko](temvorel-coingecko.json).

The complete internal research, negative controls and source responses are preserved in the delivered repository at `docs/rebrand-2026/`.
'''
(proof/'name-availability.md').write_text(proof_text,encoding='utf-8')
assets=[]
for directory in ['branding','twitter']:
    assets.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
with ZipFile(PUBLIC/'brand-kit.zip','w',ZIP_DEFLATED) as archive:
    for path in sorted(assets): archive.write(path,path.relative_to(ROOT))
print(f'Packaged {len(assets)} brand-kit files; copied {len(docs)} document slots and {len(evidence)} identity evidence files.')
