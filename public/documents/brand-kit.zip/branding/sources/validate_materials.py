"""Verify generated materials without contacting accounts or submitting transactions."""
from pathlib import Path
from html.parser import HTMLParser
from zipfile import ZipFile
import re, json, hashlib
import markdown
import pymupdf
from PIL import Image

ROOT=Path(__file__).resolve().parents[2]
D=ROOT/'docs'; P=ROOT/'website/public/documents'
md=(D/'business-plan.md').read_text(encoding='utf-8')
page=(D/'business-plan.html').read_text(encoding='utf-8')
class Plain(HTMLParser):
    def __init__(self): super().__init__(); self.parts=[]
    def handle_data(self,data): self.parts.append(data)
def plain(source):
    parser=Plain(); parser.feed(source); return re.sub(r'\s+',' ',''.join(parser.parts)).strip()
article=page.split('<article class="content">',1)[1].split('<p class="source-record">',1)[0]
expected=markdown.markdown(md.split('\n',1)[1],extensions=['tables','fenced_code','toc'])
assert plain(expected)==plain(article),'HTML changed the source document'
pdf=pymupdf.open(D/'business-plan.pdf'); pdf_text='\n'.join(p.get_text() for p in pdf)
numbers=set(re.findall(r'\$[\d,]+(?:\.\d+)?',md))
missing=[n for n in numbers if n not in pdf_text]; assert not missing,missing
assert 'Temvorel' in pdf_text and 'Vestlyr' not in pdf_text
assert all(len(p.get_text().strip())>200 for p in pdf),'Unexpected empty PDF page'
assert article.count('<table>')==12
posts=re.findall(r'```text\n(.*?)\n```',(ROOT/'twitter/posts.md').read_text(encoding='utf-8'),re.S)
assert len(posts)==3 and all(len(p)<=280 for p in posts)
bio=(ROOT/'twitter/bio.txt').read_text(encoding='utf-8').strip(); assert len(bio)<=160
sizes={}
for name in ['01-introducing-temvorel.jpg','02-release-map.jpg','03-shared-timing.jpg','avatar.jpg','avatar.png','banner.jpg']:
    with Image.open(ROOT/'twitter'/name) as image:
        target=(1600,900) if name[0].isdigit() else (1500,500) if name=='banner.jpg' else (400,400)
        assert image.size==target,(name,image.size)
        assert image.format==('PNG' if name.endswith('.png') else 'JPEG')
        sizes[name]=list(image.size)
with Image.open(ROOT/'website/public/brand/og-image.jpg') as image: assert image.size==(1200,630)
for name in ['logo.svg','logo-light.svg','logo-ivory.svg','wordmark.svg','wordmark-light.svg','favicon.svg']:
    assert (ROOT/'branding'/name).read_bytes()==(ROOT/'website/public/brand'/name).read_bytes()
parity={}
for name in ['business-plan.md','business-plan.html','business-plan.pdf','contracts.md','research.md','launch-checklist.md','name-availability.md']:
    parity[name]=(D/name).read_bytes()==(P/name).read_bytes(); assert parity[name],name
with ZipFile(P/'brand-kit.zip') as archive:
    files=archive.namelist()
    assert not any('vestlyr' in f.lower() or 'sculpture' in f.lower() for f in files)
    for filename in files: assert archive.read(filename)==(ROOT/filename).read_bytes(),filename
report={'brand':'Temvorel','source_text_preserved':True,'source_sha256':hashlib.sha256(md.encode()).hexdigest(),'tables':12,'pdf_pages':len(pdf),'monetary_values_checked':len(numbers),'missing_monetary_values':missing,'blank_pages':0,'post_characters':[len(p) for p in posts],'bio_characters':len(bio),'social_dimensions':sizes,'public_parity':parity,'brand_kit_files':len(files),'visual_review':'Social compositions and all PDF pages inspected as contact sheets; no clipped headlines, blank pages, or overlapping table text observed.','identity_status':'Prepared identity; no registration, reservation or publication performed.'}
(D/'materials-validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
(P/'materials-validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
