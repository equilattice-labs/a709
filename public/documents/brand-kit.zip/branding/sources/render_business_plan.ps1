$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$browserPath = 'C:/Program Files/Google/Chrome/Application/chrome.exe'
if (-not (Test-Path -LiteralPath $browserPath)) { $browserPath = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe' }
if (-not (Test-Path -LiteralPath $browserPath)) { throw 'Chrome or Edge is required to print the HTML edition.' }
$pdfTarget = Join-Path $projectRoot 'docs/business-plan.pdf'
$sourceUri = ([System.Uri](Join-Path $projectRoot 'docs/business-plan.html')).AbsoluteUri
$printProfile = Join-Path $env:TEMP ('temvorel-pdf-' + [guid]::NewGuid().ToString('N'))
$arguments = @('--headless=new', '--disable-gpu', '--no-pdf-header-footer', '--run-all-compositor-stages-before-draw', '--virtual-time-budget=3000', ('--user-data-dir="' + $printProfile + '"'), ('--print-to-pdf="' + $pdfTarget + '"'), ('"' + $sourceUri + '"'))
$process = Start-Process -FilePath $browserPath -ArgumentList $arguments -WindowStyle Hidden -PassThru
if (-not $process.WaitForExit(60000)) { throw 'PDF browser did not finish in 60 seconds.' }
if (-not (Test-Path -LiteralPath $pdfTarget)) { throw 'PDF output was not created.' }
Write-Output "PDF written: $pdfTarget"
