"""Generate Temvorel SVG identity and social artwork. Requires Pillow/fonttools."""
from pathlib import Path
import json
from PIL import Image, ImageDraw, ImageFont
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.varLib.instancer import instantiateVariableFont

ROOT = Path(__file__).resolve().parents[2]
B, T, W = ROOT/'branding', ROOT/'twitter', ROOT/'website/public/brand'
IDENTITY = json.loads((B/'identity.json').read_text(encoding='utf-8'))
NAME, SLUG = IDENTITY['name'], IDENTITY['slug']
for directory in (B,T,W): directory.mkdir(parents=True,exist_ok=True)
INK,BLUE,PAPER,MIST,PALE,ORANGE = '#18202c','#355dff','#ffffff','#f3f4f6','#e9eeff','#fa9a5b'
MUTED,LINE = '#5e6a7b','#d6dbe3'
TEXTBLUE = '#2e51e6'
FONT = B/'sources/Manrope-Variable.ttf'
TRACKS = [(12,12),(24,26),(36,17)]

def font(size,weight=500):
    value=ImageFont.truetype(str(FONT),int(size)); value.set_variation_by_axes([weight]); return value
def txt(d,xy,text,size=26,fill=INK,weight=500,spacing=4):
    d.multiline_text(xy,text,font=font(size,weight),fill=fill,spacing=spacing)
def mark(im,x,y,size=64,color=BLUE):
    d,u=ImageDraw.Draw(im),size/48
    for ty,cx in TRACKS:
        d.rectangle((x+6*u,y+(ty-1.5)*u,x+42*u,y+(ty+1.5)*u),fill=color)
        d.rectangle((x+cx*u,y+(ty-5)*u,x+(cx+10)*u,y+(ty+5)*u),fill=color)
def mark_svg(color):
    shapes=''.join(f'<path d="M6 {y}H42" stroke="{color}" stroke-width="3"/><rect x="{x}" y="{y-5}" width="10" height="10" fill="{color}"/>' for y,x in TRACKS)
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" role="img" aria-label="{NAME}">{shapes}</svg>'
def wordmark(im,x,y,size=64,color=INK):
    mark(im,x,y,size,color); txt(ImageDraw.Draw(im),(x+size+12,y+size*.035),NAME,size*.65,color,700)
def save(im,path): im.convert('RGB').save(path,quality=96,subsampling=0,optimize=True)
def footer(d,number,dark=False):
    color,line=(PAPER,'#718cff') if dark else (MUTED,LINE)
    d.line((80,800,1520,800),fill=line,width=2)
    txt(d,(80,828),'ROBINHOOD CHAIN TESTNET',20,color,600)
    txt(d,(1160,828),'PRODUCT NOTES  /  '+number,19,color,500)
def track_diagram(im,box,dark=False):
    d=ImageDraw.Draw(im); x,y,w,h=box
    fg=PAPER if dark else BLUE; grid='#7590ff' if dark else '#c5d0f0'
    for i in range(13):
        gx=x+i*w/12; d.line((gx,y,gx,y+h),fill=grid,width=1); d.line((gx,y+h+14,gx,y+h+22),fill=fg,width=2)
    for row in range(4):
        ry=y+row*h/4+24; d.line((x,ry,x+w,ry),fill=grid,width=2)
        start=x+(3-row)*w*.12; end=x+w-(row%2)*w*.1
        d.rectangle((start,ry-11,end,ry+11),fill=fg)
        cx=x+w*(.2+row*.16); d.rectangle((cx-15,ry-20,cx+15,ry+20),fill=ORANGE if row==2 else INK)
    txt(d,(x,y+h+40),'START',15,fg,700); txt(d,(x+w-71,y+h+40),'RELEASE',15,fg,700)

for filename,color in [('logo',BLUE),('logo-light',PAPER),('logo-ivory',PAPER)]:
    for dest in (B,W): (dest/f'{filename}.svg').write_text(mark_svg(color),encoding='utf-8')
favicon=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><rect width="48" height="48" rx="8" fill="{BLUE}"/>'+mark_svg(PAPER).split('>',1)[1]
for dest in (B,W): (dest/'favicon.svg').write_text(favicon,encoding='utf-8')
tt=instantiateVariableFont(TTFont(str(FONT)),{'wght':700},inplace=False)
glyphs,cmap,units=tt.getGlyphSet(),tt.getBestCmap(),tt['head'].unitsPerEm
paths,advance=[],0
for char in NAME:
    name=cmap[ord(char)]; pen=SVGPathPen(glyphs); glyphs[name].draw(pen)
    paths.append(f'<path transform="translate({advance} 0)" d="{pen.getCommands()}"/>'); advance+=glyphs[name].width-13
scale=33/units
for suffix,color in [('',INK),('-light',PAPER)]:
    shapes=mark_svg(color).split('>',1)[1].rsplit('</svg>',1)[0]
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {int(62+advance*scale)} 48" role="img" aria-label="{NAME}">{shapes}<g fill="{color}" transform="translate(58 36) scale({scale} {-scale})">'+''.join(paths)+'</g></svg>'
    for dest in (B,W): (dest/f'wordmark{suffix}.svg').write_text(svg,encoding='utf-8')
avatar=Image.new('RGB',(800,800),BLUE); mark(avatar,104,104,592,PAPER)
avatar=avatar.resize((400,400),Image.Resampling.LANCZOS)
avatar.save(T/'avatar.png'); avatar.save(B/'avatar.png'); save(avatar,T/'avatar.jpg')

banner=Image.new('RGB',(1500,500),MIST); d=ImageDraw.Draw(banner)
wordmark(banner,70,42,66)
txt(d,(430,112),'Value, on\nyour terms.',72,INK,700,0)
txt(d,(434,325),'Token release. Precisely arranged.',23,MUTED,500)
track_diagram(banner,(1080,87,310,234))
d.line((430,410,1390,410),fill=LINE,width=2); txt(d,(433,435),'ROBINHOOD CHAIN TESTNET',17,MUTED,600)
save(banner,T/'banner.jpg'); save(banner,W/'banner.jpg')

im=Image.new('RGB',(1600,900),MIST); d=ImageDraw.Draw(im); wordmark(im,72,54,70)
txt(d,(80,201),'TOKEN RELEASE, PRECISELY ARRANGED',21,TEXTBLUE,700)
txt(d,(73,262),'Value, on\nyour terms.',109,INK,700,0)
txt(d,(80,562),'One workspace for vesting, locks,\nstreams and vested distributions.',28,MUTED,500,10)
d.rectangle((1040,183,1520,742),fill=BLUE); track_diagram(im,(1090,282,380,290),True)
txt(d,(1090,682),'ILLUSTRATIVE SCHEDULE',17,PAPER,600); footer(d,'01'); save(im,T/f'01-introducing-{SLUG}.jpg')
og=Image.new('RGB',(1200,630),MIST); d=ImageDraw.Draw(og); wordmark(og,52,34,57)
txt(d,(60,175),'Value, on\nyour terms.',77,INK,700,0)
txt(d,(62,398),'Token release. Precisely arranged.',23,MUTED,500)
d.rectangle((802,135,1142,520),fill=BLUE); track_diagram(og,(835,191,274,218),True)
d.line((60,554,1140,554),fill=LINE,width=2); txt(d,(62,578),'ROBINHOOD CHAIN TESTNET',17,MUTED,600); save(og,W/'og-image.jpg')

im=Image.new('RGB',(1600,900),BLUE); d=ImageDraw.Draw(im); wordmark(im,72,54,70,PAPER)
txt(d,(80,201),'01 / SET TERMS     02 / FUND     03 / CLAIM',20,PAPER,600)
txt(d,(73,269),'Make the timing\nvisible.',101,PAPER,700,2)
txt(d,(80,570),'An explicit cliff. A defined cadence.\nA release path recipients can inspect.',27,PAPER,500,10)
d.rectangle((1050,215,1520,725),fill=PAPER); txt(d,(1084,250),'RELEASE MAP',20,INK,700)
track_diagram(im,(1084,329,400,249)); txt(d,(1084,684),'ILLUSTRATION / NOT LIVE DATA',15,MUTED,600)
footer(d,'02',True); save(im,T/'02-release-map.jpg')

im=Image.new('RGB',(1600,900),PAPER); d=ImageDraw.Draw(im); wordmark(im,72,54,70)
txt(d,(80,201),'VESTED DISTRIBUTIONS',21,TEXTBLUE,700)
txt(d,(73,269),'Shared timing.\nIndividual claims.',89,INK,700,4)
txt(d,(80,546),'Fund up to 100 allocations in one batch.\nEach recipient follows their own schedule.',27,MUTED,500,10)
d.rectangle((80,680,525,732),fill=PALE); txt(d,(102,693),'FULLY FUNDED / ONCHAIN TERMS',19,TEXTBLUE,700)
d.rectangle((1030,180,1520,748),fill=MIST)
for row in range(4):
    y=242+row*112; txt(d,(1060,y-10),f'0{row+1}',19,MUTED,600)
    d.line((1117,y+8,1478,y+8),fill=LINE,width=3)
    d.rectangle((1120+row*42,y-7,1467,y+23),fill=BLUE)
    d.rectangle((1190+row*63,y-18,1226+row*63,y+34),fill=ORANGE if row==2 else INK)
txt(d,(1060,711),'ILLUSTRATIVE RECIPIENT TRACKS',15,MUTED,600)
footer(d,'03'); save(im,T/'03-shared-timing.jpg')
print(f'Generated {NAME} logos, avatar, banner, OG, and three social JPGs.')
