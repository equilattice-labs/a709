# Temvorel — launch drafts

Prepared identity: **Temvorel / @temvorel / temvorel.xyz**. No account has been created, no domain acquired and no post published by this delivery. These drafts deliberately omit a live URL until ownership and hosting are confirmed. Add the verified URL at publication and recheck the character count.

## 01 — Introduction

```text
Meet Temvorel. Value, on your terms.

One workspace for vesting, locks, streams and vested distributions. Set the terms, fund the schedule, let recipients inspect and claim.

Robinhood Chain Testnet. Test tokens only.
```

Image: `01-introducing-temvorel.jpg` — 1600×900 JPG.

Alt text: A white and cobalt Temvorel card reads “Value, on your terms.” Four horizontal release tracks with staggered square control points illustrate token timing. Supporting copy names vesting, locks, streams and vested distributions. The footer labels Robinhood Chain Testnet.

## 02 — Release map

```text
Make the timing visible.

Choose an explicit cliff, cadence and end date. Fund the allocation once; recipients claim what has vested. Optional cancellation preserves vested value and refunds only the unvested balance.

Temvorel. Testnet only.
```

Image: `02-release-map.jpg` — 1600×900 JPG.

Alt text: A cobalt Temvorel card reads “Make the timing visible.” Set terms, fund and claim appear as three steps. A white release-map panel shows four tracks and square timing markers, clearly labeled as an illustration rather than live data.

## 03 — Vested distributions

```text
Shared timing. Individual claims.

Create up to 100 vested allocations in one Temvorel batch. Fund them together; recipients inspect and claim independently as tokens unlock.

Robinhood Chain Testnet. No real-value assets.
```

Image: `03-shared-timing.jpg` — 1600×900 JPG.

Alt text: A white Temvorel card reads “Shared timing. Individual claims.” Four numbered blue recipient tracks share a grid while square controls appear at different positions. Supporting copy explains fully funded batches of up to 100 allocations. The footer labels Robinhood Chain Testnet.

## Profile assets

- `avatar.jpg` and `avatar.png`: 400×400; a white three-track mark on cobalt, safe for a circular crop.
- `banner.jpg`: 1500×500; Temvorel wordmark, “Value, on your terms.” and a measured timing diagram. Essential text is clear of the lower-left profile overlap.
- `bio.txt`: profile text below X's 160-character limit.

At publication, keep the testnet label, use the matching image and alt text, and verify all links. No token launch, future airdrop, investment return, independent audit or official Robinhood partnership is implied.
