# Vestlyr brand guidelines

## Identity

**Vestlyr** is the product name. Use lowercase **vestlyr** in the drawn wordmark; use **Vestlyr** in prose. The intended matching domain and social handle are **vestlyr.xyz** and **@vestlyr**. Refer to the separate name-availability report for the dated checks and registration status.

**Tagline:** Good things. On schedule.

**Positioning:** Token distribution, thoughtfully timed. Programmable vesting, token locks, payment streams and batch airdrops for teams building on Robinhood Chain.

**Current stage:** Robinhood Chain testnet. Keep this stage explicit in launch materials. Vestlyr is an independent project; the use of a network name does not communicate a partnership or endorsement.

## Visual system

| Role | Color | Use |
| --- | --- | --- |
| Forest | `#102822` | Primary text, deep backgrounds, navigation |
| Lime | `#d4ff5a` | Primary calls to action, symbol, selected states |
| Ivory | `#f6f6ed` | Main canvas, text against dark surfaces |
| Muted sage | `#a9bab0` | Supporting content against forest backgrounds |

Use generous whitespace, large sentence-case headlines, thin rules and a restrained modular layout. Alternate ivory, forest and lime panels to create visual rhythm. Use forest text on lime; white text on lime lacks sufficient contrast.

**Typography:** Manrope, weight 400 for body copy, 500–600 for headings, 700 for the wordmark and small labels. The font is provided under the SIL Open Font License in `sources/Manrope-OFL.txt`. SVG wordmarks contain vector outlines and do not require font loading.

## Symbol and wordmark

The original symbol is a geometric V with a small separated rising segment. The V makes the brand recognizable; the release above it suggests timing and forward movement. It is not derived from Robinhood's identity or the reference website's artwork.

- `logo.svg`: forest symbol for ivory or lime surfaces.
- `logo-light.svg`: lime symbol for forest surfaces.
- `logo-ivory.svg`: ivory symbol for dark surfaces.
- `wordmark.svg`: outlined forest wordmark and symbol.
- `wordmark-light.svg`: outlined ivory wordmark and symbol.
- `avatar.png`: 400 × 400 pixel profile symbol.

Keep clear space around the symbol at least equal to one-quarter of its width. Do not stretch, rotate, add shadows to, or redraw the symbol. Use at least 24 CSS pixels for the standalone symbol. The favicon includes its own background and padding.

## Hero sculpture

The lime helical ribbon expresses continuous release through time. The original geometry is rendered locally with controlled lighting. Its transparent background supports both ivory and forest surfaces. Preserve its aspect ratio; subtle motion in the website can be added with a slow transform and disabled for reduced-motion users.

Website assets are in `website/public/brand/`:

- `hero-sculpture.webp`: preferred production version, transparent.
- `hero-sculpture.png`: lossless transparent master.
- `banner.jpg`: 1500 × 500 social banner.
- `og-image.jpg`: 1200 × 630 link-sharing card.
- Logo, wordmark and favicon SVGs.

## Voice

Speak clearly about a practical outcome: set a schedule, fund it, distribute tokens, view progress, claim what has unlocked. Prefer confidence grounded in working product behavior. Avoid invented traction, superlatives, financial return promises and implied official network affiliation. Use “onchain” consistently.

## Social kit

The `twitter/` directory contains three distinct 1600 × 900 JPG introduction posts, a 1500 × 500 banner, 400 × 400 JPG/PNG avatars, a biography and English post copy with alt text. The assets are prepared for review and publication; creating them does not create an account or publish a post.

## Reproduction

Run `python branding/sources/render_sculpture.py` followed by `python branding/sources/build_brand.py`. Python dependencies are Pillow and fonttools. The bundled Manrope font is the only third-party design dependency. All compositions and geometry are generated from the included source code.
